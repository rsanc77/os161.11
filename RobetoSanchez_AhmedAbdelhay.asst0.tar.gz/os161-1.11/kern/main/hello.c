/**
 * added by Roberto Sanchez
 * Hello world function
 */
void hello(void){
   kprintf("Hello World \n");
}

